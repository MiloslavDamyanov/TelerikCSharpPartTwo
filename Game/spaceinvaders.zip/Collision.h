#include "mydrawengine.h"

bool CheckRECTColl(RECT D1, RECT D2, RECT &OverLap);
bool CheckPixelPColl(MyPicture* Pic1, MyPicture* Pic2, RECT S1, RECT D1, RECT S2, RECT D2, RECT &OverLap);
